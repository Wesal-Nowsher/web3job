import React from "react";
import Topsection from "./top-main-section";
import Tabledata from "./tabledata";


 function home(){
    return(
        <>
        <div className="container-fluid">
        <Topsection/>
        <Tabledata />
        </div>
        </>
    )
}

export default home;

