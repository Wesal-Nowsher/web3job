import React from "react";

import icons from '../../assets/icons.png';

 function tabledata(){
    return(
        <>
            <div className="row">
                <div className="pl-5 pr-5">
                    <div className="row">
                        <div className="col-5 d-flex">
                            <div className="logo">
                                <img src={icons} />
                            </div>
                            <div className="d-flex flex-column ">
                                <h4>Front-End Developer</h4>
                                <p>Parcel</p>
                            </div>
                        </div>
                        <div className="col-5">

                        </div>
                        <div className="col-2">

                        </div>
                    </div>
                </div>
              
            
            </div>
          
        
        </>
    )
}

export default tabledata;

